package com.example.internship.web;

import com.example.internship.model.entity.TaskEntity;
import com.example.internship.model.view.TaskViewModel;
import com.example.internship.service.TaskService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/tasks")
public class TaskController {
    private final ModelMapper modelMapper;
    private final TaskService taskService;

    public TaskController(ModelMapper modelMapper, TaskService taskService) {
        this.modelMapper = modelMapper;
        this.taskService = taskService;
    }

    //SHOW ALL TASKS
    @GetMapping("/all-tasks")
    public String allTasks(Model model) {
        List<TaskViewModel> tasks = this.taskService.findAllTasks();

        model.addAttribute("tasks", tasks);

        return "all-tasks";

    }

    //SHOW ALL TASK DETAILS
    @GetMapping("/details/{id}")
    public String details(@PathVariable Long id, Model model, @AuthenticationPrincipal UserDetails userDetails) {
        TaskEntity taskById = taskService.findTaskById(id);

        model.addAttribute("task", taskById);

        return "task-details";

    }
}
