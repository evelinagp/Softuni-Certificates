package com.example.internship.schedulers;


import com.example.internship.service.TaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class TasksCountScheduler {

    Logger logger = LoggerFactory.getLogger(TasksCountScheduler.class);
    private final TaskService taskService;

    public TasksCountScheduler(TaskService taskService) {
        this.taskService = taskService;
    }

    //The idea is every month at 7 am on 1 day of the month to show that statistic,
    //but only to show that is working it's set to appear in every 5 seconds
//    @Scheduled(cron= "* 00 07 1 * *")
    @Scheduled(cron = "*/5 * * * * *")
    public void tasksCountSchedule() {

        Integer tasksCount = taskService.countTasksCount();

        logger.info("The tasks count for last month is: {}", tasksCount);

    }
}
