package com.example.internship.model.service;

import com.example.internship.model.entity.EmployeeEntity;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.*;
import java.time.LocalDate;

public class TaskServiceModel {
    private Long id;
    private String title;
    private String description;
    private EmployeeEntity assignee;
    private LocalDate dueDate;

    public TaskServiceModel() {
    }


    @NotBlank(message = "Title can not be empty string!")
    @Size(min = 3, max = 20, message = "Title length must be between 3 and 20 characters!")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @NotBlank(message = "Description can not be empty field!")
    @Size(min = 15, max = 500, message = "Description length must be between 15 and 500 characters!")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    //    @NotNull(message = "Assignee can not be empty field!")
    public EmployeeEntity getAssignee() {
        return assignee;
    }

    public void setAssignee(EmployeeEntity assignee) {
        this.assignee = assignee;
    }

    @FutureOrPresent
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
