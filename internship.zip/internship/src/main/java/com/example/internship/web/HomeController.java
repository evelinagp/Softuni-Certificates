package com.example.internship.web;

import com.example.internship.model.entity.TaskEntity;
import com.example.internship.model.view.EmployeeViewModel;
import com.example.internship.model.view.TaskViewModel;
import com.example.internship.service.EmployeeService;
import com.example.internship.service.TaskService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
public class HomeController {

    private final TaskService taskService;

    public HomeController( TaskService taskService) {
        this.taskService = taskService;
    }

    @GetMapping()
    public String index(Model model) {
        return "index";
    }

    @GetMapping("/contacts")
    public String contacts() {
        return "contacts";
    }

    @GetMapping("/about")
    public String about() {
        return "about";

    }

    @GetMapping("/top-five-employees")
    public String allTasks(Model model) {
        Map<String, Set<TaskEntity>> topFiveEmployees = taskService
                .findFiveEmployeesWithLargestCountOfTasksOrderByCountDescNameAsc();
        model.addAttribute("employees", topFiveEmployees);

        return "top-five-employees";

    }

}
