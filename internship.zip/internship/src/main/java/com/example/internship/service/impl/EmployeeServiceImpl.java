package com.example.internship.service.impl;

import com.example.internship.model.binding.EmployeeRegisterBindingModel;
import com.example.internship.model.entity.EmployeeEntity;
import com.example.internship.model.entity.RoleEntity;
import com.example.internship.model.entity.TaskEntity;
import com.example.internship.model.service.EmployeeServiceModel;
import com.example.internship.model.view.EmployeeViewModel;
import com.example.internship.repository.EmployeeRepository;
import com.example.internship.repository.RoleRepository;
import com.example.internship.service.AppUserDetailsService;
import com.example.internship.service.EmployeeService;
import com.example.internship.service.RoleService;
import com.example.internship.service.TaskService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    private final ModelMapper modelMapper;
    private final EmployeeRepository employeeRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserDetailsService appUserDetailsService;
    private final String adminPass;
    private final RoleService roleService;


    public EmployeeServiceImpl(ModelMapper modelMapper, EmployeeRepository userRepository,
                               RoleRepository roleRepository, PasswordEncoder passwordEncoder,
                               UserDetailsService appUserDetailsService,
                               @Value("${app.default.admin.password}") String adminPass,
                               RoleService roleService) {
        this.modelMapper = modelMapper;
        this.employeeRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.appUserDetailsService = appUserDetailsService;
        this.adminPass = adminPass;
        this.roleService = roleService;
    }

    @Override
    public boolean isEmailExists(EmployeeRegisterBindingModel employeeRegisterBindingModel) {
        return employeeRepository.existsByEmail(employeeRegisterBindingModel.getEmail());
    }

    @Override
    public void registerAndLogin(EmployeeRegisterBindingModel employeeRegisterBindingModel) {

        Set<RoleEntity> userRole = this.roleRepository.findById(2L).stream().collect(Collectors.toSet());


        var newEmployee = new EmployeeEntity();
        newEmployee.setDateOfBirth(employeeRegisterBindingModel.getDateOfBirth());
        newEmployee.setEmail(employeeRegisterBindingModel.getEmail());
        newEmployee.setFullName(employeeRegisterBindingModel.getFirstName() + " " + employeeRegisterBindingModel.getLastName());
        newEmployee.setMonthlySalary(BigDecimal.valueOf(1500));
        newEmployee.setPassword(passwordEncoder.encode(employeeRegisterBindingModel.getPassword()));
        newEmployee.setPhoneNumber(employeeRegisterBindingModel.getPhoneNumber());
        newEmployee.setRoles(userRole);


        employeeRepository.saveAndFlush(newEmployee);

        UserDetails userDetails =
                appUserDetailsService.loadUserByUsername(newEmployee.getEmail());

        Authentication auth =
                new UsernamePasswordAuthenticationToken(
                        userDetails,
                        userDetails.getPassword(),
                        userDetails.getAuthorities()
                );

        SecurityContextHolder.
                getContext().
                setAuthentication(auth);
    }

    @Override
    public EmployeeEntity findByEmail(String email) {
        return this.employeeRepository.findByEmail(email).orElseThrow();
    }

    @Override
    public boolean existById(Long id) {
        return this.employeeRepository.existsById(id);
    }

    @Transactional
    @Override
    public void deleteEmployee(Long id) throws Exception {
        EmployeeEntity employee = this.employeeRepository.findById(id).orElseThrow(Exception::new);
        if (employee.getId() != 1) {
            this.employeeRepository.deleteById(id);
        }
    }

    @Transactional
    @Override
    public void changeCurrentEmployeeRole(Long id) throws Exception {
        EmployeeEntity employee = this.employeeRepository.findById(id).orElseThrow(Exception::new);
        Set<RoleEntity> employeeRole = this.roleRepository.findById(2L).stream().collect(Collectors.toSet());
        Set<RoleEntity> adminRole = this.roleRepository.findById(1L).stream().collect(Collectors.toSet());
        AppUserDetailsService userDetailServiceImpl = new AppUserDetailsService(this.employeeRepository);
        RoleEntity adminEntity = employee.getRoles().stream().filter(r -> r.getName().name().equalsIgnoreCase("ADMIN")).findAny().orElse(null);
        RoleEntity employeeEntity = employee.getRoles().stream().filter(r -> r.getName().name().equalsIgnoreCase("EMPLOYEE")).findAny().orElse(null);
        if (adminEntity != null && employee.getId() != 1) {
            employee.setRoles(employeeRole);
            userDetailServiceImpl.mapUser(this.modelMapper.map(employee, EmployeeEntity.class));
        } else if (employeeEntity != null) {
            adminRole.add(employeeEntity);
            employee.setRoles(adminRole);
            userDetailServiceImpl.mapAdmin(this.modelMapper.map(employee, EmployeeEntity.class));
        }
    }

    @Override
    public List<EmployeeServiceModel> findAllEmployees() {
        return this.employeeRepository.findAll()
                .stream()
                .map(user -> {
                    EmployeeServiceModel employeeServiceModel = this.modelMapper.map(user, EmployeeServiceModel.class);
                    int whitespaceIndex = user.getFullName().indexOf(" ");
                    employeeServiceModel.setFirstName(user.getFullName().substring(0, whitespaceIndex));
                    employeeServiceModel.setLastName(user.getFullName().substring(whitespaceIndex + 1));

                    user.getRoles()
                            .forEach(role -> employeeServiceModel.getRoles().add(role));
                    return employeeServiceModel;
                })
                .collect(Collectors.toList());

    }

    @Override
    public void updateEmployee(EmployeeServiceModel employeeServiceModel) {
        EmployeeEntity employeeById = employeeRepository.findById
                (employeeServiceModel.getId()).orElseThrow();

        employeeById.setDateOfBirth(employeeServiceModel.getDateOfBirth());
        employeeById.setEmail(employeeServiceModel.getEmail());
        employeeById.setFullName(employeeServiceModel.getFirstName() + " " + employeeServiceModel.getLastName());
        employeeById.setMonthlySalary(employeeServiceModel.getMonthlySalary());
        employeeById.setPassword(passwordEncoder.encode(employeeServiceModel.getPassword()));
        employeeById.setPhoneNumber(employeeServiceModel.getPhoneNumber());

        this.employeeRepository.save(employeeById);

    }

    @Override
    public EmployeeEntity findEmployeeById(Long id) {
        return this.employeeRepository.findById(id).orElseThrow();
    }

    @Override
    public boolean isAssigneeEmailExists(String email) {
        return this.employeeRepository.existsByEmail(email);
    }


}





