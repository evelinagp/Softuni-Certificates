package com.example.internship.service.impl;

import com.example.internship.service.RoleService;
import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService {
}
