package com.example.internship.model.view;

import com.example.internship.model.entity.RoleEntity;
import com.example.internship.model.entity.TaskEntity;

import java.util.Set;

public class EmployeeViewModel {
    private Long id;
    private String email;
    private String fullName;
    private Set<RoleEntity> roles;
    private Set<TaskEntity> tasks;

    public EmployeeViewModel() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Set<RoleEntity> getRoles() {
        return roles;
    }

    public void setRoles(Set<RoleEntity> roles) {
        this.roles = roles;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Set<TaskEntity> getTasks() {
        return tasks;
    }

    public void setTasks(Set<TaskEntity> tasks) {
        this.tasks = tasks;
    }
}
