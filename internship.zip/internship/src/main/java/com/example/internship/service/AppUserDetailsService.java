package com.example.internship.service;

import com.example.internship.model.entity.EmployeeEntity;
import com.example.internship.model.entity.RoleEntity;
import com.example.internship.repository.EmployeeRepository;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

// NOTE: This is not annotated as @Service, because we will return it as a bean.
    public class AppUserDetailsService implements UserDetailsService {

        private final EmployeeRepository employeeRepository;

        public AppUserDetailsService(EmployeeRepository userRepository) {
            this.employeeRepository = userRepository;
        }

        @Override
        public UserDetails loadUserByUsername(String email)
                throws UsernameNotFoundException {
            return employeeRepository.
                    findByEmail(email).
                    map(this::map).
                    orElseThrow(() -> new UsernameNotFoundException("User with email " + email + " not found!"));
        }

        private UserDetails map(EmployeeEntity employeeEntity) {
            return
                    User.builder().
                            username(employeeEntity.getEmail()).
                            password(employeeEntity.getPassword()).
                            authorities(employeeEntity.
                                    getRoles().
                                    stream().
                                    map(this::map).
                                    collect(Collectors.toSet())).
                            build();
        }

        private GrantedAuthority map(RoleEntity roleEntity) {
            return new SimpleGrantedAuthority("ROLE_" +
                    roleEntity.getName().name());
        }

    public UserDetails mapUser(EmployeeEntity employeeEntity) {
        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        grantedAuthorities.add(new SimpleGrantedAuthority("EMPLOYEE"));

        return new User(
                employeeEntity.getEmail(),
                employeeEntity.getPassword(),
                grantedAuthorities
        );
    }

    public UserDetails mapAdmin(EmployeeEntity employeeEntity) {
        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        grantedAuthorities.add(new SimpleGrantedAuthority("ADMIN"));

        return new User(
                employeeEntity.getEmail(),
                employeeEntity.getPassword(),
                grantedAuthorities
        );
    }
}
