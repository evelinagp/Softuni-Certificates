package com.example.internship.web;


import com.example.internship.model.binding.EmployeeLoginBindingModel;
import com.example.internship.model.binding.EmployeeRegisterBindingModel;
import com.example.internship.service.EmployeeService;
import org.modelmapper.ModelMapper;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
@RequestMapping("/users")
public class EmployeeController {

    private final EmployeeService employeeService;
    private final ModelMapper modelMapper;

    public EmployeeController(EmployeeService employeeService, ModelMapper modelMapper) {
        this.employeeService = employeeService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }


    @PostMapping("/register")
    public String registerConfirm(@Valid EmployeeRegisterBindingModel employeeRegisterBindingModel
            , BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        System.out.println();
        if (bindingResult.hasErrors() ||
                !employeeRegisterBindingModel.getPassword().equals(employeeRegisterBindingModel.getConfirmPassword())
                || this.employeeService.isEmailExists(employeeRegisterBindingModel)) {
            redirectAttributes
                    .addFlashAttribute("employeeRegisterBindingModel", employeeRegisterBindingModel);
            redirectAttributes
                    .addFlashAttribute("org.springframework.validation.BindingResult.employeeRegisterBindingModel", bindingResult);

            return "redirect:register";
        }

        employeeService.registerAndLogin(employeeRegisterBindingModel);
        return "redirect:/";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }


    // NOTE: This should be post mapping!
   @PostMapping("/login-error")
    public String onFailedLogin(
            @ModelAttribute(UsernamePasswordAuthenticationFilter.SPRING_SECURITY_FORM_USERNAME_KEY) String username,
            RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute(UsernamePasswordAuthenticationFilter.SPRING_SECURITY_FORM_USERNAME_KEY, username);
        redirectAttributes.addFlashAttribute("bad_credentials",
                true);

        return "redirect:/users/login";
    }

    @GetMapping("/logout")
    public String logout(HttpSession httpSession) {
        httpSession.invalidate();
        return "redirect:/";
    }


    @ModelAttribute
    public EmployeeRegisterBindingModel employeeRegisterBindingModel() {
        return new EmployeeRegisterBindingModel();
    }

    @ModelAttribute
    public EmployeeLoginBindingModel employeeLoginBindingModel() {
        return new EmployeeLoginBindingModel();
    }
}


