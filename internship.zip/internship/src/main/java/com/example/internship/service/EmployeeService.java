package com.example.internship.service;

import com.example.internship.model.binding.EmployeeRegisterBindingModel;
import com.example.internship.model.entity.EmployeeEntity;
import com.example.internship.model.service.EmployeeServiceModel;
import com.example.internship.model.view.EmployeeViewModel;

import java.util.List;

public interface EmployeeService {
    boolean isEmailExists(EmployeeRegisterBindingModel employeeRegisterBindingModel);

    void registerAndLogin(EmployeeRegisterBindingModel employeeRegisterBindingModel);

    EmployeeEntity findByEmail(String email);

    boolean existById(Long id);

    void deleteEmployee(Long id) throws Exception;

    void changeCurrentEmployeeRole(Long id) throws Exception;

    List<EmployeeServiceModel> findAllEmployees();


    void updateEmployee(EmployeeServiceModel employeeServiceModel);

    EmployeeEntity findEmployeeById(Long id);


    boolean isAssigneeEmailExists(String email);
}
