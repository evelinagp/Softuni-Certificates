package com.example.internship.model.entity.enums;

public enum RoleNameEnum {
     ADMIN, EMPLOYEE;
}
