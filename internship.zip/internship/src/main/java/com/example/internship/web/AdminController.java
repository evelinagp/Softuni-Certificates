package com.example.internship.web;

import com.example.internship.model.binding.TaskAddBindingModel;
import com.example.internship.model.entity.EmployeeEntity;
import com.example.internship.model.entity.TaskEntity;
import com.example.internship.model.entity.enums.RoleNameEnum;
import com.example.internship.model.service.EmployeeServiceModel;
import com.example.internship.model.service.TaskServiceModel;
import com.example.internship.model.view.EmployeeViewModel;
import com.example.internship.service.EmployeeService;
import com.example.internship.service.TaskService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.io.IOException;
import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/pages/admins")
public class AdminController {

    private final TaskService taskService;
    private final EmployeeService employeeService;
    private final ModelMapper modelMapper;


    public AdminController(TaskService taskService, EmployeeService employeeService, ModelMapper modelMapper) {
        this.taskService = taskService;
        this.employeeService = employeeService;
        this.modelMapper = modelMapper;
    }

    //EDIT TASK
    @GetMapping("/update-task/{id}")
    public String edit(@PathVariable Long id, Model model) {
        TaskEntity taskById = this.taskService.findTaskById(id);
        TaskServiceModel task = modelMapper.map(taskById, TaskServiceModel.class);
        model.addAttribute("taskServiceModel", task);

        return "/update-task";
    }

    @PutMapping("/update-task/{id}")
    public String editTask(@Valid TaskServiceModel taskServiceModel,
                           BindingResult bindingResult, RedirectAttributes redirectAttributes,
                           @PathVariable Long id) throws IOException {
        if (bindingResult.hasErrors() ||
                !this.employeeService.isAssigneeEmailExists(taskServiceModel.getAssignee().getEmail())
               /* || this.taskService.findTaskByTitle(taskServiceModel.getTitle())*/) {

            redirectAttributes.addFlashAttribute("taskServiceModel", taskServiceModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.taskServiceModel", bindingResult);

            return "/update-task";
        }

        this.taskService.updateTask(taskServiceModel);

        return "redirect:/tasks/all-tasks";
    }

    //DELETE TASK
//    @Transactional
    @GetMapping("/delete-task/{id}")
    public String deleteTask(@PathVariable Long id) throws Exception {
        this.taskService.deleteTaskById(id);
        return "redirect:/tasks/all-tasks";
    }

    //ADD TASK
    @GetMapping("/add-task")
    public String addTask() {

        return "/add-task";
    }

    @PostMapping("/add-task")
    public String addTaskConfirm(@Valid TaskAddBindingModel taskAddBindingModel,
                                 BindingResult bindingResult, RedirectAttributes redirectAttributes,
                                 Principal principal) throws IOException {

        if (bindingResult.hasErrors() ||
                     !this.employeeService.isAssigneeEmailExists(taskAddBindingModel.getAssignee().getEmail())
        || this.taskService.findTaskByTitle(taskAddBindingModel.getTitle())) {

                redirectAttributes.addFlashAttribute("taskAddBindingModel", taskAddBindingModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.taskAddBindingModel", bindingResult);
            return "redirect:add-task";
        }

        boolean taskExists = this.taskService.isTaskExists(taskAddBindingModel.getTitle());
        if (taskExists) {
            return "redirect:add-task";
        }
        TaskServiceModel taskServiceModel = this.modelMapper.map(taskAddBindingModel, TaskServiceModel.class);

        this.taskService.addNewTask(taskServiceModel, principal);
        return "redirect:/tasks/all-tasks";

    }

    //MANAGE USERS PAGE
    @GetMapping("/manage-employees")
    public String adminPanel(Model model) {
        List<EmployeeViewModel> employeeViewModels = this.employeeService.findAllEmployees().stream()
                .map(employeeServiceModel -> {
                    EmployeeViewModel employeeViewModel = this.modelMapper.map(employeeServiceModel, EmployeeViewModel.class);
                    employeeViewModel.setFullName(employeeServiceModel.getFirstName() + " " + employeeServiceModel.getLastName());
                    return employeeViewModel;
                })
                .collect(Collectors.toList());

        model.addAttribute("allEmployees", employeeViewModels);
        model.addAttribute("admin", RoleNameEnum.ADMIN);
        return "manage-employees";
    }

    //REMOVE EMPLOYEE

    @GetMapping("/delete-employee/{id}")
    public String deleteUser(@PathVariable Long id) throws Exception {
        boolean isEmployeeExist = this.employeeService.existById(id);
        if (isEmployeeExist) {
            this.employeeService.deleteEmployee(id);
        }
        return "redirect:/pages/admins/manage-employees";
    }


    //CHANGE USER ROLE
    @GetMapping("/change-role/{id}")
    public String changeUserRole(@PathVariable Long id) throws Exception {
        boolean isEmployeeExist = this.employeeService.existById(id);
        if (isEmployeeExist) {
            this.employeeService.changeCurrentEmployeeRole(id);
        }
        return "redirect:/pages/admins/manage-employees";
    }

    //EDIT EMPLOYEE
    @GetMapping("/update-employee/{id}")
    public String updateEmployee(@PathVariable Long id, Model model) {
        EmployeeEntity employeeById = this.employeeService.findEmployeeById(id);
        EmployeeServiceModel employee = modelMapper.map(employeeById, EmployeeServiceModel.class);
        int whitespaceIndex = employeeById.getFullName().indexOf(" ");
        employee.setFirstName(employeeById.getFullName().substring(0, whitespaceIndex));
        employee.setLastName(employeeById.getFullName().substring(whitespaceIndex + 1));

        model.addAttribute("employeeServiceModel", employee);

        return "/update-employee";
    }

    @PutMapping("/update-employee/{id}")
    public String updateEmployeeConfirm(@Valid EmployeeServiceModel employeeServiceModel,
                                        BindingResult bindingResult, RedirectAttributes redirectAttributes,
                                        @PathVariable Long id) throws IOException {
        if (bindingResult.hasErrors() ||
                this.employeeService.isAssigneeEmailExists(employeeServiceModel.getEmail())) {

            redirectAttributes.addFlashAttribute("employeeServiceModel", employeeServiceModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.employeeServiceModel", bindingResult);

            System.out.println();
            return "/update-employee";
        }

        this.employeeService.updateEmployee(employeeServiceModel);

        return "redirect:/pages/admins/manage-employees";
    }


    @ModelAttribute
    private TaskAddBindingModel taskAddBindingModel() {
        return new TaskAddBindingModel();
    }

    @ModelAttribute
    private TaskServiceModel taskServiceModel() {
        return new TaskServiceModel();
    }

}

