package com.example.internship.service.impl;

import com.example.internship.model.entity.TaskEntity;
import com.example.internship.model.service.TaskServiceModel;
import com.example.internship.model.view.EmployeeViewModel;
import com.example.internship.model.view.TaskViewModel;
import com.example.internship.repository.TaskRepository;
import com.example.internship.service.EmployeeService;
import com.example.internship.service.TaskService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.security.Principal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TaskServiceImpl implements TaskService {
    private final TaskRepository taskRepository;
    private final ModelMapper modelMapper;
    private final EmployeeService employeeService;

    public TaskServiceImpl(TaskRepository taskRepository, ModelMapper modelMapper, EmployeeService employeeService) {
        this.taskRepository = taskRepository;
        this.modelMapper = modelMapper;
        this.employeeService = employeeService;
    }

    @Override
    public TaskEntity findTaskById(Long id) {
        return this.taskRepository.findById(id).orElseThrow();
    }

    @Override
    public void deleteTaskById(Long id) {
        //    TaskEntity task = this.taskRepository.findById(id).orElseThrow();
        try {
            this.taskRepository.deleteById(id);
        } catch (Exception ex) {
            String message = ex.getMessage();
            System.out.println(message + " because the task is assigned to employee!");
        }
    }

    @Override
    public void updateTask(TaskServiceModel taskServiceModel) {
        TaskEntity taskById = taskRepository.findById
                (taskServiceModel.getId()).orElseThrow();

        System.out.println();
        taskById.setId(taskServiceModel.getId());
        taskById.setTitle(taskServiceModel.getTitle());
        taskById.setDescription(taskServiceModel.getDescription());
        taskById.setDueDate(taskServiceModel.getDueDate());
        taskById.setAssignee(employeeService.findByEmail(taskServiceModel.getAssignee().getEmail()));
        this.taskRepository.save(taskById);

    }

    @Override
    public boolean isTaskExists(String title) {
        return this.taskRepository.existsByTitle(title);
    }

    @Override
    public void addNewTask(TaskServiceModel taskServiceModel, Principal principal) {

        TaskEntity task = this.modelMapper.map(taskServiceModel, TaskEntity.class);
        task.setDueDate(taskServiceModel.getDueDate());
        task.setDescription(taskServiceModel.getDescription());
        task.setDueDate(taskServiceModel.getDueDate());
        task.setAssignee(employeeService.findByEmail(taskServiceModel.getAssignee().getEmail()));

        this.taskRepository.saveAndFlush(task);
    }

    @Transactional
    @Override
    public List<TaskViewModel> findAllTasks() {
        return this.taskRepository.findAll().stream()
                .map(task -> modelMapper.map(task, TaskViewModel.class))
                .collect(Collectors.toList());

    }

    @Override
    public List<TaskEntity> findAllTasksEntities() {
        return this.taskRepository.findAll();
    }

    @Override
    public Map<String, Set<TaskEntity>> findFiveEmployeesWithLargestCountOfTasksOrderByCountDescNameAsc() {
        Map<String, Set<TaskEntity>> tasksByEmployee = new HashMap<>();

        findAllTasksEntities().stream().forEach(t -> {
            String fullName = t.getAssignee().getFullName();
            tasksByEmployee
                    .computeIfAbsent(fullName, task -> new HashSet<>())
                    .add(t);
        });

        LocalDate dt1 = LocalDate.parse("2023-01-31");
        LocalDate dt2 = LocalDate.parse("2023-03-01");

        Set<TaskEntity> setSorted = this.taskRepository.findAll().stream().filter(t -> {
            return t.getDueDate().isAfter(dt1) && t.getDueDate().isBefore(dt2);
        }).collect(Collectors.toSet());

//        Map<String, Set<TaskEntity>> collect = tasksByEmployee.entrySet().stream()
//                .filter(t -> t.getValue().retainAll(setSorted))
//                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        Map<String, Set<TaskEntity>> collection = tasksByEmployee.entrySet().stream()
                //  .filter(t -> t.getValue().retainAll(setSorted))
                .sorted((e1, e2) -> {
                    int result = Integer.compare(e2.getValue().size(), e1.getValue().size());
                    if (result == 0) {
                        result = e1.getKey().compareTo(e2.getKey());
                    }
                    return result;
                })
                .limit(5)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

        return collection;

    }

    @Override
    public Integer countTasksCount() {
        LocalDate dt1 = LocalDate.parse("2023-01-31");

        LocalDate dt2 = LocalDate.parse("2023-03-01");

        //probably more correct impl -> return t.getDueDate().minusMonths(1)
        return this.taskRepository.findAll().stream().filter(t -> {
            return t.getDueDate().isAfter(dt1) && t.getDueDate().isBefore(dt2);

        }).toList().size();

    }

    @Override
    public boolean findTaskByTitle(String title) {
        return this.taskRepository.existsByTitle(title);
    }
}



