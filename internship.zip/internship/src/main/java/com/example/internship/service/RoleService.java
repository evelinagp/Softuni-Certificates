package com.example.internship.service;

public interface RoleService {
}
