package com.example.internship.service;

import com.example.internship.model.entity.TaskEntity;
import com.example.internship.model.service.TaskServiceModel;
import com.example.internship.model.view.TaskViewModel;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface TaskService {
    TaskEntity findTaskById(Long id);

    void deleteTaskById(Long id);

    void updateTask(TaskServiceModel taskServiceModel);

    boolean isTaskExists(String title);

    void addNewTask(TaskServiceModel taskServiceModel, Principal principal);

    List<TaskViewModel> findAllTasks();

    List<TaskEntity> findAllTasksEntities();

    Map<String, Set<TaskEntity>> findFiveEmployeesWithLargestCountOfTasksOrderByCountDescNameAsc();

    Integer countTasksCount();

    boolean findTaskByTitle(String title);
}
