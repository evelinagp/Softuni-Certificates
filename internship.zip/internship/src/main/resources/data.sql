-- -- INSERT ROLES -------------------------------------------

INSERT INTO roles (id, name)
VALUES (1, 'ADMIN'),
       (2, 'EMPLOYEE');

-- -- INSERT USERS -------------------------------------------

INSERT INTO employees (id, date_of_birth, email, full_name, monthly_salary, password, phone_number)
VALUES (1, '1993-01-01', 'admin@example.com', 'Admin Adminov', 4000,
        '23b95ca352fe19b348e8f1b5a5a1cc1e23c54910ae9a89a35234f1e4791426e0b4af400a98cabb2e', '0898 123456'),
       (2, '1999-06-06', 'ivan@example.com', 'Ivan Ivanov', 1500,
        'faece043d5eac617582f4dd2cde7e2849606c5294c938d1eae7b4778018904b0eaab4846cff44d78', '0898 654321'),
       (3, '2001-06-06', 'peter@example.com', 'Peter Petrov', 1800,
        '23b95ca352fe19b348e8f1b5a5a1cc1e23c54910ae9a89a35234f1e4791426e0b4af400a98cabb2e', '0898 126578'),
       (4, '2003-09-06', 'georgi@example.com', 'Georgi Georgiev', 2500,
        'faece043d5eac617582f4dd2cde7e2849606c5294c938d1eae7b4778018904b0eaab4846cff44d78', '0899 986547'),
       (5, '1998-12-18', 'viktor@example.com', 'Viktor Viktorov', 2800,
        '23b95ca352fe19b348e8f1b5a5a1cc1e23c54910ae9a89a35234f1e4791426e0b4af400a98cabb2e', '0899 999626'),
       (6, '2000-05-30', 'deni@example.com', 'Denislav Blagoev', 2100,
        'faece043d5eac617582f4dd2cde7e2849606c5294c938d1eae7b4778018904b0eaab4846cff44d78', '0896 968743'),
       (7, '2004-01-26', 'desi@example.com', 'Desislava Petrova', 1900,
        '23b95ca352fe19b348e8f1b5a5a1cc1e23c54910ae9a89a35234f1e4791426e0b4af400a98cabb2e', '0895 349567'),
       (8, '2002-07-24', 'stela@example.com', 'Stela Ivanova', 1700,
        'faece043d5eac617582f4dd2cde7e2849606c5294c938d1eae7b4778018904b0eaab4846cff44d78', '0895 349567');

-- -- INSERT USERS_ROLES -------------------------------------------
INSERT INTO employees_roles (employee_entity_id, roles_id)
VALUES (1, 1),
       (1, 2),
       (2, 2);

-- -- INSERT TASKS -------------------------------------------

INSERT INTO tasks (id, description, due_date, title, assignee_id)
VALUES (1,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-15', 'Task1', 1),
       (2,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-02', 'Task2', 1),
       (3,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-24', 'Task3', 1),
       (4,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-14', 'Task4', 2),
       (5,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-01', 'Task5', 2),
       (6,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-22', 'Task6', 2),
       (7,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-17', 'Task7', 3),
       (8,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-12', 'Task8', 3),
       (9,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-28', 'Task9', 3),
       (10,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-20', 'Task10', 3),
       (11,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-11', 'Task11', 4),
       (12,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-13', 'Task12', 4),
       (13,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-16', 'Task13', 4),
       (14,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-18', 'Task14', 4),
       (15,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-09', 'Task15', 4),
       (16,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-05', 'Task16', 7),
       (17,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-02', 'Task17', 7),
       (18,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-09', 'Task18', 6),
       (19,
        'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab accusantium aspernatur assumenda consequatur delectus deserunt dolorum eius est illo impedit ipsam iusto labore maiores molestiae nobis non, quasi tempora voluptatibus.',
        '2023-02-05', 'Task19', 8);